//task01
abstract class Animal {
	abstract void makesound();
	void eat(){
	System.out.println("Animal is eating");
}}
class Dog extends Animal{
	void makesound(){
	System.out.println("Dog is barking");
}}
class Cat extends Animal{
	void makesound(){
	System.out.println("Cat says meow");
}
} 
public class task01{
public static void main(String[] args){
	Dog dog=new Dog();
	Cat cat=new Cat();
	dog.makesound();
	dog.eat();
	cat.makesound();
	cat.eat();

}}