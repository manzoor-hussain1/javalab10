//task02
interface Vehicle {
    void start();
    void stop();
}
class Car implements Vehicle {
    public void start() {
        System.out.println("Car is starting with a key ignition.");
    }

    public void stop() {
        System.out.println("Car is stopping using hydraulic brakes.");
    }
}
class Bike implements Vehicle {
    public void start() {
        System.out.println("Bike is starting with a kick start.");
    }

    public void stop() {
        System.out.println("Bike is stopping using disc brakes.");
    }
}
public class task02{
    public static void main(String[] args) {
        Vehicle myCar = new Car();
        Vehicle myBike = new Bike();

        System.out.println("Car Actions:");
        myCar.start();
        myCar.stop();

        System.out.println("\nBike Actions:");
        myBike.start();
        myBike.stop();
    }
}
