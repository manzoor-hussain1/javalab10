//task05
abstract class Employee {
    protected String name;
    protected int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    abstract double calculateSalary();
}
interface TaxPayer {
    void payTax();
}
class FullTimeEmployee extends Employee implements TaxPayer {
    private double monthlySalary;

    public FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    @Override
    double calculateSalary() {
        return monthlySalary;
    }

    @Override
    public void payTax() {
        double tax = calculateSalary() * 0.2; // 20% tax
        System.out.println(name + " (Full-Time) paid tax: $" + tax);
    }
}
class PartTimeEmployee extends Employee implements TaxPayer {
    private double hourlyRate;
    private int hoursWorked;

    public PartTimeEmployee(String name, int id, double hourlyRate, int hoursWorked) {
        super(name, id);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    double calculateSalary() {
        return hourlyRate * hoursWorked;
    }

    @Override
    public void payTax() {
        double tax = calculateSalary() * 0.1; // 10% tax
        System.out.println(name + " (Part-Time) paid tax: $" + tax);
    }
}
public class task05{
    public static void main(String[] args) {
        FullTimeEmployee alice = new FullTimeEmployee("Alice", 101, 5000);
        System.out.println("Salary of " + alice.name + ": $" + alice.calculateSalary());
        alice.payTax();

        System.out.println();
        PartTimeEmployee bob = new PartTimeEmployee("Bob", 202, 20, 80);
        System.out.println("Salary of " + bob.name + ": $" + bob.calculateSalary());
        bob.payTax();
    }
}
