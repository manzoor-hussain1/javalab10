//task04
interface Flyable {
    void fly();
}
interface Swimmable {
    void swim();
}
class Duck implements Flyable, Swimmable {
    public void fly() {
        System.out.println("Duck is flying using its wings.");
    }
    public void swim() {
        System.out.println("Duck is swimming gracefully in the pond.");
    }
}
public class task04 {
    public static void main(String[] args) {
        Duck donald = new Duck();

        donald.fly();
        donald.swim();
    }
}
